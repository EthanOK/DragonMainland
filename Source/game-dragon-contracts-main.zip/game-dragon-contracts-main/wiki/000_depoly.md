
* 手动验证开源某个合约

npx hardhat verify --network bscmain 0x3a70F8292F0053C97c4B394e2fC98389BdE765fb

npx hardhat verify --network mainnet DEPLOYED_CONTRACT_ADDRESS "Constructor argument 1"

https://hardhat.org/plugins/nomiclabs-hardhat-etherscan.html
