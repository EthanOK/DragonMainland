
* 龙合约

https://bscscan.com/address/0x01f6b08CAD9ACeB1c2D945863f66336dA8009518

* 钱包 0x01f6b08CAD9ACeB1c2D945863f66336dA8009518

测试链无记录

* DragonMainlandToken 龙合约

https://bscscan.com/address/0x3a70f8292f0053c97c4b394e2fc98389bde765fb

* 预售合约

https://bscscan.com/address/0x6fe8f3de6301eadd052bffdaecaa2d9ce1120bf5


* DMS DragonMainlandShardsToken

0x9a26e6D24Df036B0b015016D1b55011c19E76C87

* DMP DragonMiraclePotionToken

0x000E9E0Cc008D4C2BE1132a2F9c44504907773fB
