

* 主要的方法仅 admin 可以调用 且以链下签名的方式调用执行

* createDragonEggs

创建龙蛋

1万以内的创世龙 父、母id=0

tokenId 10000 以内的 冰冻时间7天

tokenId 大于1万以上的是繁殖龙 冰冻时间为3天

* hatchDragonEggs

孵化龙蛋

繁殖龙 id是1万以上，父、母龙Id不能相同且不能为0

龙的孩子列表


* setDragonAttribute

升级龙属性值，一个龙只能升级3次

* setDragonSkill

升级龙技能等级，一个龙 前4个技能可以升级4次，最后1个技能（Talent）可以升级5次

* addDragonBreedCount

龙繁殖次数 最多可以繁殖7次

