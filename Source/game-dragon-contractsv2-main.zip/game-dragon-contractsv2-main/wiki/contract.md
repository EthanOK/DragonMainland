
* PreSaleDragonEgg.sol 龙蛋预售合约

* DragonMainToken.sol 龙蛋NFT721合约


* 已发合约

1）DMS
代币名称 DMS 
代币全称 Dragon Mainland Shards
小数位数 6位
总供应量 10亿

* 待发合约

1) 龙合约 DMT（NFT721）
代币名称 DMT
代币全称 Dragon Mainland Token
小数位数 1位
总供应量 无上限

2）龙骨合约 DMB（NFT1155）
代币名称 DMB
代币全称 Dragon Mainland Bone
小数位数 1位
总供应量 无上限
